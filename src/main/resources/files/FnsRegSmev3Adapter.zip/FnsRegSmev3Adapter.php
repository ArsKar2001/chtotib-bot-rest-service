<?php

namespace adapters\FnsRegSmev3Adapter;

use app\helpers\ArrayHelper;
use app\models\Dictionary;
use app\models\RequestResultStateHistory;
use app\modules\smev\envelope\v3\Attach;
use app\modules\smev\queues\Timeout;
use app\modules\adapter\helpers\EnvelopeHelper;
use app\services\Archive;
use app\models\File;
use app\services\store\File as DiskFile;
use app\models\Request;
use app\constants\ProcessState;
use app\modules\smev\helpers\DOMDocument;
use app\modules\adapter\helpers\Validations;
use app\modules\smev\envelope\v3\Envelope;
use app\modules\smev\helpers\UUID;
use app\modules\smev\queues\PollStrategy;
use app\modules\smev\queues\QueueItemInterface;

use app\services\Context;
use app\modules\adapter\services\DenisyukKitHelper;
use app\modules\adapter\smev\v3\BaseAdapter;
use app\modules\adapter\Helper;
use app\services\store\Space;
use app\services\store\Store;

use app\services\X509Certificate;
use Elasticsearch\Endpoints\Cat\Help;
use Jaspersoft\Dto\User\User;
use Yii;


/**
 * Class BaseAdapter
 * N#787
 * @package tests\unit\service\adapters\smev\debug
 */
class FnsRegSmev3Adapter extends BaseAdapter
{
//Справочные данные для работы с сервисом ФНС:
    private $files_types = [
        'ZayavIP' => ['code' => '01', 'type' => 'ЗаявлениеИП', 'codeSVDREG' => ''],
        'ZayavUL' => ['code' => '01', 'type' => 'ЗаявлениеЮЛ', 'codeSVDREG' => ''],
        'GosPoshlina' => ['code' => '04', 'type' => 'ПДГоспошлина', 'codeSVDREG' => '020001'],
        'ZayavUSN' => ['code' => '05', 'type' => 'ЗаявлениеУСН', 'codeSVDREG' => '020111'],
        'IzmUchDokum' => ['code' => '10', 'type' => 'ИзмененияУчредительныйДокумент', 'codeSVDREG' => '021004']
    ];
    private $content_files_types = [
        'xml' => 'xml',
        'rtf' => 'rtf',
        'tiff' => 'tiff',
        'tif' => 'tiff',
        'doc' => 'ms-word',
        'docx' => 'ms-word',
        'xls' => 'ms-excel',
        'xlsx' => 'ms-excel',
        'pdf' => 'pdf'
    ];
    private $arrCodeSVDREG = [
        //YUL
        'Р11001' => '010011',
        'Р12001' => '010020',
        'Р12003' => '010120',
        'Р13001' => '010031',
        'Р14001' => '010040',
        'Р14002' => '010044',
        'Р15001' => '010051',
        'Р16001' => '010060',
        'Р16002' => '010071',
        'Р16003' => '010083',
        'Р17001' => '010090',
        //IP
        'Р21001' => '011011',
        'Р21002' => '011012',
        'Р24001' => '011020',
        'Р24002' => '011030',
        'Р26001' => '011040',
        'Р26002' => '011051',
        'Р27002' => '011062'
    ];
    private $statusCodes = [
        10 => 'Запрос поставлен в очередь на обработку',
        20 => 'При обработке ТК в ИС ФНС России выявлена некорректность, допущенная при его формировании',
        21 => 'При обработке ТК в РО выявлена некорректность в сведениях, содержащихся в ТК, не позволяющая провести его дальнейшую обработку',
        30 => 'Документы приняты в РО, подготовлена расписка в приеме документов',
        40 => 'Принято решение об отказе в государственной регистрации',
        48 => 'Принято решение о приостановлении государственной регистрации (после получения данного значения статуса последующие обращения к данному ВС рекоментуется производить не ранее, чем по прошествии 7 дней)',
        50 => 'Запись о государственной регистрации внесена в реестр'
    ];

    static function GetName()
    {
        return "Адаптер для регистрации ИП и ЮЛ в ФНС";
    }

    // Функция получения XML файла описи из ТК
    public function generateInventory($params) {
        $request = Request::findOne($params['parameters']['request_id']);
        $fields = $this->getFieldsForInventory($request);
        $template = $this->getLocalTemplatePath('OP_REG.twig');
        $xml_utf8 = Helper::renderPath($template, $fields);
        $xml = Helper::xmlUtf8To($xml_utf8, 'windows-1251');
        $file = File::populate($fields['IdFile'] . '.xml', $xml, null, true);
        return (object) [
            'result' => true,
            'file' => [
                'hash' => $file->hash,
                'name' => $fields['IdFile'] . '.xml'
            ],
            'msg' => 'Файл описи успешно сформирован ' . date('d.m.Y H:i:s')
        ];
    }

    // Генерация контейнера
    public function generateContainer($params) {
        $request = Request::findOne($params['parameters']['request_id']);
        $fields = $this->getFieldsForContainer($request);

        $template = $this->getLocalTemplatePath('containerDescription.twig');
        $xml_utf8 = Helper::renderPath($template, $fields);
        $xml = Helper::xmlUtf8To($xml_utf8, 'windows-1251');
        $space = Store::getSpace(Space::TEMP);
        $contDescDiskFile = DiskFile::inst($space)->name('packageDescription.xml')->write($xml);

        $archive = new Archive();
        $archive->Add($contDescDiskFile, 'packageDescription.xml');
        foreach ($fields['files'] as $fileInfo) {
            $file = File::findOne($fileInfo->IdDoc);
            $archive->Add($file->getDiskFile(), $fileInfo->filename);
            $archive->Add(DiskFile::inst($space)->name($fileInfo->filename. '.p7s')->write(base64_decode($file->getSign()->sign)));
        }
        if ($zipFile = $archive->zip(DiskFile::inst($space)->name($fields['folderName'] . '.zip')))
            $container = File::getOrCreateByFile($zipFile);
        else
            throw new \Exception('Ошибка при архивации контейнера!');

        return (object) [
            'result' => true,
            'file' => [
                'hash' => $container->hash,
                'name' => $container->name
            ],
            'msg' => 'Контейнер успешно сформирован ' . date('d.m.Y H:i:s')
        ];
    }

    /*
     * Функции для работы со СМЭВ-3
     */

    // Сформировать запрос
    public function CreateRequest($request, $parameters) : QueueItemInterface
    {
        Yii::info("<<<<<<  --------------- BEGIN  --------------- >>>>>>", __METHOD__);

        $template = $this->getLocalTemplatePath("FnsReg.twig"); //указываем шаблон запроса
        $user_data = $this->getUserData($request);
        Yii::info(json_encode($user_data, 256), __METHOD__);
        if (!$user_data->result)
            throw new \Exception($user_data->message);
        $xml = Helper::renderPath($template, $user_data->fields);
        Yii::info('$xml: '.$xml, __METHOD__);

        $envelope = Envelope::create(Envelope::SEND_REQUEST_REQUEST, [
            'messageID' => $uuid = UUID::v1(),
            'messagePrimaryContent' => $xml,
            'testMode' => $this->isTestMode()
        ]);
        Yii::info('Запрос сформирован!', __METHOD__);

        // Добавляем файл с контейнером
        $attach = new Attach($this->smevManager->attach, Attach::FTP);
        $file = File::getByUuid($user_data->file['hash'], true);
        $attach->add($file);
        $envelope->applyAttach($attach);

        //Подписываем soap-сообщение запроса
        $envelope->applySign();
        Yii::info('Подпись добавлена: ' . serialize($envelope), __METHOD__);

        $data = $envelope->getMessageBody();
        Yii::info($data, __METHOD__);
        $request->setResultState(RequestResultStateHistory::RESULT_STATUS_NOT_RECEIVED);

        //Ставим сформированное сообщение СМЭВ-3 в очередь на отправку
        $callback = $this->genMetaCallback($request->id, $parameters);
        $item = $this->genQueueItem($envelope, $callback, Context::getUser()->id, PollStrategy::LONG, Timeout::val(15)->d(), 'PRDDOKREGResponse');

        Yii::info("<<<<<< -------------------- END ------------------- >>>>>>", __METHOD__);
        return $item;
    }

    // Подготовка данных для шаблона СМЭВ-3 запроса
    private function getUserData($request) {
        $form = $request->fields_data['serviceData'];

        if ($form['main/serviceType'] == '')
            return (object) ['result' => false, 'message' => 'Не указан вид услуги!'];
        $RegType = (stristr($form['main/serviceType'], 'Р2')) ? 'ИП' : 'ЮЛ';

        if (!is_array($form['files/Container/Container_file']))
            return (object) ['result' => false, 'message' => 'Контейнер не найден!'];

        if (!is_array($form['files/OP-REG/OP_REG_file']) || strlen($form['files/OP-REG/OP_REG_file']['name']) != 54)
            return (object) ['result' => false, 'message' => 'Не найден файл описи!'];
        $reestrUuid = substr($form['files/OP-REG/OP_REG_file']['name'], -36, 32);

        return (object) [
            'result' => true,
            'fields' => [
                'VidGosReg' => (($RegType == 'ИП') ? '2' : '1'),
                'IdZapros' => $reestrUuid
            ],
            'file' => $form['files/Container/Container_file']
        ];
    }

    // Обработать ответ на запрос
    public function ProcessResponseCallback($request, $parameters, $httpResponse)
    {
        $envelope = Envelope::create(Envelope::GET_RESPONSE_RESPONSE, ['httpResponse' => $httpResponse]);

        if ($error = $envelope->getError()) {
            Helper::postToChat($error, $request);
            Yii::error($error, __METHOD__);
            $request->setResultState(RequestResultStateHistory::RESULT_STATUS_REVISION);
            return ProcessState::DOCUMENT_RECEIVING;
        } else {
            $dom = $envelope->getDom();

            if ($dom->getElementsByTagName('PRDDOKREGResponse')->length > 0) {
                if ($this->getResultCode($dom) == RequestResultStateHistory::RESULT_STATUS_REJECTED) {
                    $error = 'Запрос отклонен';
                    Helper::postToChat($error, $request);
                    Yii::error($error, __METHOD__);
                    $request->setResultState(RequestResultStateHistory::RESULT_STATUS_REVISION);
                    return ProcessState::DOCUMENT_RECEIVING;
                }

                $response = $dom->getElementsByTagName('PRDDOKREGResponse')->item(0);
                $message = 'Запрос поставлен в очередь на обработку';
                $IdFns = $response->getAttribute('ИдЗапросФНС');
                $IdMfc = $response->getAttribute('ИдЗапрос');

                $resultFieldsData = $request->result_fields_data;
                Helper::postToChat($message, $request);
                $resultFieldsData['main/ResultMessage'] = $message;
                $resultFieldsData['main/IdFns'] = $IdFns;
                $resultFieldsData['main/IdMfc'] = $IdMfc;

                $received_data = $request->received_data;
                $received_data['IdFns'] = $IdFns;
                $received_data['IdMfc'] = $IdMfc;

                //Файлы
                $fileDocs =  EnvelopeHelper::saveResponseFiles($envelope);
                if (count($fileDocs) > 0) {
                    DenisyukKitHelper::macroElementDocumentBegin('main');
                    foreach ($fileDocs as $fileDoc) {
                        $resultFieldsData = ArrayHelper::merge(
                            $resultFieldsData,
                            DenisyukKitHelper::macroElementDocument($fileDoc, ['added' => true])
                        );
                    }
                    DenisyukKitHelper::macroElementDocumentEnd('main');
                }
                $request->result_fields_data = $resultFieldsData;
                $request->received_data = $received_data;

                Yii::info(
                    'Сохранение запроса: ' . ($request->save() ? 'OK' : serialize($request->getErrorSummary(true))),
                    __METHOD__
                );

                //Если все норм отправляем запросы статусов
                $this->startGetStatusPoll($request->id, $parameters['user_id']);

                return null;
            }
            else {
                Helper::postToChat('Не найден элемент PRDDOKREGResponse в ответе на запрос FnsReg', $request);
                Yii::error('Не найден элемент PRDDOKREGResponse в ответе на запрос FnsReg', __METHOD__);
                $request->setResultState(RequestResultStateHistory::RESULT_STATUS_REVISION);
                return ProcessState::DOCUMENT_RECEIVING;
            }
        }
    }

    // Получить внешний статус на основе ответа
    private function getResultCode(DOMDocument $dom)
    {
        $responseNode = $dom->getElementsByTagName('PRDDOKREGResponse')->item(0);


        $responseCodeNode = $responseNode->getAttribute('КодОбраб');
        if ($responseCodeNode && $responseCodeNode == 10) // 10 – запрос поставлен в очередь на обработку
            return RequestResultStateHistory::RESULT_STATUS_INTERIM_DEPARTMENT_RESULT;
        else  //получен не успешный ответ
            return RequestResultStateHistory::RESULT_STATUS_REJECTED;
    }

    // Сформировать запроса статуса
    public function CreateGetStatusRequest($request, $parameters): QueueItemInterface
    {
        $received_data = $request->received_data;
        $template = $this->getLocalTemplatePath("getStatus.twig");
        $xml = Helper::renderPath($template, $received_data);

        Yii::info('$xml: '.$xml, __METHOD__);
        $envelope = Envelope::create(Envelope::SEND_REQUEST_REQUEST, [
            'messageID' => $uuid = UUID::v1(),
            'messagePrimaryContent' => $xml,
            'testMode' => $this->isTestMode()
        ]);

        $envelope->applySign();
        $data = $envelope->getMessageBody();
        Yii::info($data, __METHOD__);

        $callback = $this->genMetaCallback($request->id, $parameters, 'ProcessGetStatusResponseCallback', 'onTimeoutGetStatus');
        $item = $this->genQueueItem($envelope, $callback, $parameters['user_id'], PollStrategy::SHORT, PollStrategy::TYPICAL_TIMEOUT_DAY, 'STATDOKREGResponse');
        return $item;
    }

    public function CreateGetStatusRequestServiceFromButton($params) {
        $request = Request::findOne($params['parameters']['request_id']);
        if (!$request)
            throw new \Exception('Не найдено обращение по данному request_id');
        $params['user_id'] = Yii::$app->user->id;
        try {
            $this->StartPoll(
                $request->id,
                'CreateGetStatusRequest',
                60 * 15,
                Timeout::val(15)->d(),
                [
                    'user_id' => $params['user_id']
                ]
            );
        }
        catch (\Exception $exception) {
            throw new \Exception('Неизвестная оши при запуске polling-а! ' . $exception->getMessage());
        }
        return (object) ['result' => true, 'message' => 'Polling запущен!'];
        /*else
            throw new \Exception('Неизвестная оши при запуске polling-а!');*/
    }

    // Обработать ответ на запрос статуса
    public function ProcessGetStatusResponseCallback($request, $parameters, $httpResponse)
    {
        $Envelope = Envelope::create(Envelope::GET_RESPONSE_RESPONSE, ['httpResponse' => $httpResponse]);
        if ($error = $Envelope->getError()) {
            //$this->StopPoll($parameters['smev3_poll_id']);
            Helper::postToChat($error, $request);
            Yii::error($error, __METHOD__);
            return null;
        }
        $dom = $Envelope->getDom();
        $responseElem = $dom->getElementsByTagName('STATDOKREGResponse')->item(0);
        if ($responseElem) {
            if (!$responseElem->hasAttributes()) {
                Helper::postToChat('Некорректный ответ от ведомства! Нет атрибутов в корневом тэге ответа', $request);
                Yii::error('Некорректный ответ от ведомства! Нет атрибутов в корневом тэге ответа', __METHOD__);
                return null;
            }
            $statusCode = $responseElem->getAttribute('СтатусДок');
            $received_data = $request->received_data;
            $resultFieldsData = $request->result_fields_data;
            if (!empty($received_data['StatusCode']) && $statusCode == $received_data['StatusCode']) {
                //Helper::postToChat('Повторный ответ, уже обработан ранее', $request);
                $this->clearRequestChat($parameters['smev3_poll_id']);
                Yii::info('Повторный ответ, уже обработан ранее по обращению '.$request->id, __METHOD__);
                return null;
            }

            $stopPolling = false;

            // Смотрим статусы и заводим polling дальше, если требуется
            if (in_array($statusCode, ['50'])) { // Исполнено
                $request->setResultState(RequestResultStateHistory::RESULT_STATUS_RECEIVED);
                $processState = ProcessState::RESULT_ISSUE;
                $stopPolling = true;
            }
            elseif (in_array($statusCode, ['40'])) { // Отказ
                $request->setResultState(RequestResultStateHistory::RESULT_STATUS_REJECTED);
                $processState = ProcessState::RESULT_ISSUE;
                $stopPolling = true;
            }
            elseif (in_array($statusCode, ['48'])) { // Приостановка
                $request->setResultState(RequestResultStateHistory::RESULT_STATUS_STOPPED);
                $processState = ProcessState::RESULT_ISSUE;
                $stopPolling = true;
            }
            elseif (in_array($statusCode, ['20', '21'])) { // Ошибка в транспортном контейнере
                $request->setResultState(RequestResultStateHistory::RESULT_STATUS_REVISION);
                $processState = ProcessState::DOCUMENT_RECEIVING;
                $stopPolling = true;
            }
            elseif (in_array($statusCode, ['10', '30'])) { // Принято в ведомстве
                Helper::postToChat('Принято ведомством', $request);
                $processState = null;
            }
            else
                $processState = null;
            if ($stopPolling)
                $this->StopPoll($parameters['smev3_poll_id']);

            //Файлы
            $fileDocs =  EnvelopeHelper::saveResponseFiles($Envelope);
            Yii::info('Файлы: '.json_encode($fileDocs, 256), __METHOD__);
            if (count($fileDocs) > 0) {
                Yii::info('Файлы есть!', __METHOD__);
                DenisyukKitHelper::macroElementDocumentBegin('main');
                foreach ($fileDocs as $fileDoc) {
                    $resultFieldsData = ArrayHelper::merge(
                        $resultFieldsData,
                        DenisyukKitHelper::macroElementDocument($fileDoc, ['added' => true])
                    );
                }
                DenisyukKitHelper::macroElementDocumentEnd('main');
                Yii::info('Файлы добавлены!', __METHOD__);
            }

            //Сохранение данных
            $received_data['StatusCode'] = $statusCode;
            $resultFieldsData['main/ResultMessage'] = $this->statusCodes[$statusCode];
            $request->received_data = $received_data;
            $request->result_fields_data = $resultFieldsData;
            $request->save();

            return $processState;
        }
        else {
            Helper::postToChat($error, $request);
            Yii::error('Некорректный ответ от ведомства! Не найден корневой элемент ответа STATDOKREGResponse', __METHOD__);
            return null;
        }
    }

    // По окончанию таймаута
    public function onTimeoutGetStatus($request)
    {
        //$this->startGetStatusPoll($request->id, \app\models\User::SYSTEM_USER);
        Helper::postToChat("Превышено время ожидания ответа на запрос статуса от органа", $request);

    }

    // Общий обработчик по таймауту Poll запросов
    public function ProcessTimeoutPoll($request, $parameters=[])
    {
        //parent::ProcessTimeoutPoll($request, $parameters);
    }

    private function startGetStatusPoll($request_id, $user_id) {
        $this->StartPoll($request_id, 'CreateGetStatusRequest', 60 * 1, Timeout::val(15)->d(), ['user_id' => $user_id]);
    }

    /*
     *	Вспомогательные функции для генерации описи и контейнера
     */

    // Сформировать массив с данными о документах
    private function getFiles($request) {
        $form = $request->fields_data['serviceData'];
        if (!isset($form['main/serviceType']) || trim($form['main/serviceType']) == '')
            throw new \Exception('Не выбран вид услуги');
        $serviceType = trim(explode(' ', $form['main/serviceType'])[0]);
        $RegType = (stristr($serviceType, 'Р2')) ? 'ИП' : 'ЮЛ';
        if (isset($this->arrCodeSVDREG[$serviceType]))
            $this->files_types[($RegType == 'ИП') ? 'ZayavIP' : 'ZayavUL']['codeSVDREG'] = $this->arrCodeSVDREG[$serviceType];
        else
            throw new \Exception('Данный вид услуги не доступен для отправки орган! ($arrCodeSVDREG не содержит serviceType)');
        $files = [];
        foreach ($form as $key => $value) {
            if (stristr($key,'_file') && !empty($value) && is_array($value)) {
                $docname = explode('/', substr($key, 6))[0];
                $macroDocumentName = $form['files/' . $docname . '#label'];
                $filename = $value['name'];
                $file = File::getByUuid($value['hash'], true);
                $diskFile = $file->getDiskFile();
                $sign = $file->getSign();
                $mimeType = $diskFile->getMime();
                $name = ($docname == 'LoadStatement') ? (($RegType == 'ИП') ? 'ZayavIP' : 'ZayavUL') : str_replace('-', '_', $docname);
                if (!array_key_exists($name, $this->files_types)) {
                    if (stristr($name, 'PrilozhDokum_'))
                        $this->files_types[$name] = ['code' => '03', 'type' => 'ПриложенныйДокумент', 'codeSVDREG' => explode('_', $name)[1]];
                    elseif (stristr($name, 'UchDokum_'))
                        $this->files_types[$name] = ['code' => '09', 'type' => 'УчредительныйДокумент', 'codeSVDREG' => explode('_', $name)[1]];
                    elseif (substr($name, 0, 6) == 'OP_REG')
                        $this->files_types[$name] = ['code' => '07', 'type' => 'ОписьДокументов'.$RegType, 'codeSVDREG' => ''];
                    else {
                        $name = 'PrilozhDokum_'.$name;
                        $this->files_types[$name] = ['code' => '03', 'type' => 'ПриложенныйДокумент', 'codeSVDREG' => '020002'];
                    }
                }
                $fileType = explode('.', $filename);
                $fileType = $fileType[count($fileType) - 1];
                if (!array_key_exists($fileType, $this->content_files_types))
                    throw new \Exception("Не поддерживаемый сервисом налоговой формат файла - $fileType");
                if ($docname == 'LoadStatement' && !in_array($fileType, ['tiff', 'tif', 'pdf']))
                    throw new \Exception('Формат заявления должен быть tiff или pdf!');

                $filename = ((stristr($name, 'PrilozhDokum')) ? 'PrilozhDokum' : ((stristr($name, 'UchDokum')) ? 'UchDokum' : $name)).'_'.str_replace('-', '', $value['hash']).'.'.$fileType;

                // Данные подписи
                if (empty($sign))
                    throw new \Exception('Файл ' . $macroDocumentName . ' не подписан с помощью ЭЦП!');
                $signInfo = X509Certificate::instance($sign->sign, X509Certificate::PKCS7);
                $signInfo = $signInfo->toArray();

                $fileObj = (object) [
                    'name' => $name,
                    'filename' => $filename,
                    'uuid' => str_replace('-', '', $value['hash']),
                    'mimeType' => $mimeType,
                    'fileType' => $fileType,
                    'signer' => (object) [
                        'lastname' => $signInfo['subject']['SN'],
                        'firstname' => explode(' ', $signInfo['subject']['G'])[0],
                        'patronymic' => explode(' ', $signInfo['subject']['G'])[1],
                    ]
                ];
                $files[] = (object) [
                    'hash' => $value['hash'],
                    'IdDoc' => $fileObj->uuid,
                    'IdDocForTR' => (substr($filename, 0, 6) == 'OP_REG') ? substr(explode('.', $form['files/OP-REG/OP_REG_file']['name'])[0], -32) : $fileObj->uuid,
                    'CodeTypeDocument' => $this->files_types[$fileObj->name]['code'],
                    'TypeDocument' => $this->files_types[$fileObj->name]['type'],
                    'CodeSVDREG' => $this->files_types[$fileObj->name]['codeSVDREG'],
                    'ContainType' => $this->content_files_types[$fileObj->fileType],
                    'filename' => $fileObj->filename,
                    'signer' => $fileObj->signer
                ];

            }
        }
        if (count($files) == 0)
            throw new \Exception('Не найдены файлы для отправки');
        return $files;
    }

    private function getFieldsForInventory($request) {
        $requestFields = $request->fields_data;
        $form = $requestFields['serviceData'];
        $client = $requestFields['clients'][0]['filled']['client'];

        //Вид услуги, тип лица
        if (!isset($form['main/serviceType']) || trim($form['main/serviceType']) == '')
            throw new \Exception('Не выбран вид услуги');
        $serviceType = trim(explode(' ', $form['main/serviceType'])[0]);
        $RegType = (stristr($serviceType, 'Р2')) ? 'ИП' : 'ЮЛ';

        //ИНН ФЛ (заявителя)
        $INNFl = ($RegType == 'ИП') ? $client['INN'] : $form['main/INNFl'];
        if (strlen($INNFl) != 12)
            throw new \Exception('Не корректно заполнен ИНН ФЛ заявителя');

        //E-mail
        if (trim($form['main/Email']) == '' || !Validations::checkEmail($form['main/Email']))
            throw new \Exception('Не корректно заполнен адрес электронной почты');

        //Проверка на наличие заявления
        if (empty($form['files/LoadStatement/LoadStatement_file']))
            throw new \Exception('Отсутствует файл заявления');

        //Проверка на наличие заявления
        if ($RegType == 'ЮЛ' && empty($form['main/CompanyName']))
            throw new \Exception('Заполните "Наименование юридического лица на русском языке (полное)" ');

        $files = $this->getFiles($request);
        $reestrUuid = str_replace('-', '', UUID::v1());
        $IdFile = 'OP_REG'.(($RegType == 'ИП') ? 'IP' : 'UL').'_'.date('Ymd').'_'.$reestrUuid;

        $fields = [
            'RegType' => $RegType,
            'ServiceType' => $serviceType,
            'IdFile' => $IdFile,
            'CodeSFRD' => $serviceType,
            'INNFl' => $INNFl,
            'Email' => $form['main/Email'],
            'files' => $files
        ];

        $fields = array_merge($this->getFnsInfo($RegType), $fields);

        if ($RegType == 'ИП') {
            $fields['PersonLastName'] = $client['family_name'];
            $fields['PersonName'] = $client['first_name'];
            $fields['PersonMiddleName'] = (empty($client['patro_name'])) ? '' : $client['patro_name'];
        } else {
            $fields['CompanyName'] = $form['main/CompanyName']; //str_replace('"', '&quot', $form['main/CompanyName']);
            $fields['CompanyOGRN'] = $form['main/CompanyOGRN'];
            $delegate = $requestFields['clients'][0]['filled']['delegate'];
            if (!empty($delegate)) {
                $fields['PersonLastName'] = $delegate['family_name'];
                $fields['PersonName'] = $delegate['first_name'];
                $fields['PersonMiddleName'] = (empty($delegate['patro_name'])) ? '' : $delegate['patro_name'];
            }
            elseif ($client['type'] == 'ClientFl') {
                if (stristr($serviceType, '11001')) {
                    $fields['PersonLastName'] = $client['family_name'];
                    $fields['PersonName'] = $client['first_name'];
                    $fields['PersonMiddleName'] = (empty($client['patro_name'])) ? '' : $client['patro_name'];
                }
                else
                    throw new \Exception('Заявителем должно выступать юридическое лицо с представителем (физическое лицо)');
            }
            else
                throw new \Exception('Не указан представитель для юридического лица!');
        }

        // Признак выдачи
        if (!empty($form['main/PriznakVid']) && substr($form['main/PriznakVid'], 0, 1) != '0')
            $fields['PrVisBum'] = substr($form['main/PriznakVid'], 0, 1);

        return $fields;
    }

    private function getFieldsForContainer($request) {
        $requestFields = $request->fields_data;
        $form = $requestFields['serviceData'];

        //Вид услуги, тип лица
        if (!isset($form['main/serviceType']) || trim($form['main/serviceType']) == '')
            throw new \Exception('Не выбран вид услуги');
        $serviceType = trim(explode(' ', $form['main/serviceType'])[0]);
        $RegType = (stristr($serviceType, 'Р2')) ? 'ИП' : 'ЮЛ';
        $fields = $this->getFnsInfo($RegType);
        $fields['RegType'] = $RegType;

        // Проверка наличия описи ТК
        if (isset($form['files/OP-REG/OP_REG_file']) && is_array($form['files/OP-REG/OP_REG_file']))
            $fields['reestrUuid'] = substr(explode('.', $form['files/OP-REG/OP_REG_file']['name'])[0], -32);
        else
            throw new \Exception('Не сформирована опись для транспортного контейнера!');

        $fields['mfcINN'] = $requestFields['created_mfc']['INN'];
        $fields['folderName'] = 'FNS_'.$fields['mfcINN'].'_'.$fields['CodeNO'].'_'.$fields['reestrUuid'].'_'.$RegType.'_'.$fields['transactionCode'].'_'.$fields['docTypeCode'];
        $fields['files'] = $this->getFiles($request);
        return $fields;
    }

    // Данные налоговой для межвед обмена по СМЭВ
    private function getFnsInfo($RegType) {
        $fnsDic = Dictionary::find()->where(['short_name' => 'fnsData', 'type_id' => 1])->limit(1)->one();
        $fnsDataDic = Dictionary::find()->where(['parent_id' => $fnsDic->id])->all();
        Yii::info(serialize($fnsDataDic), __METHOD__);
        if (is_array($fnsDataDic)) {
            foreach ($fnsDataDic as $item)
                if ($item->short_name == 'КодНО') $CodeNO = $item->description;
                elseif ($item->short_name == 'версияФормата') $VersionFormat = $item->description;
                elseif ($item->short_name == 'transactionCode') $transactionCode = $item->description;
                elseif ($item->short_name == 'docTypeCode') $docTypeCode = $item->description;
                elseif ($item->short_name == 'ВерсФормИП' && $RegType == 'ИП') $VersForm = $item->description;
                elseif ($item->short_name == 'ВерсФормЮЛ' && $RegType == 'ЮЛ') $VersForm = $item->description;
                elseif ($item->short_name == 'ВерсПрог') $VersProg = $item->description;
        }
        else
            throw new \Exception('Ошибка: нет справочника с данными налоговой!');
        if (!isset($CodeNO, $VersionFormat, $transactionCode, $docTypeCode, $VersForm, $VersProg))
            throw new \Exception('Ошибка: в справочнике с данными налоговой не найдены нужные элементы! Требуются элементы с краткими наименованиями: КодНО, версияФормата, transactionCode , docTypeCode, ВерсФормИП, ВерсФормЮЛ, ВерсПрог');
        return [
            'CodeNO' => $CodeNO,
            'VersionFormat' => $VersionFormat,
            'transactionCode' => $transactionCode,
            'docTypeCode' => $docTypeCode,
            'VersForm' => $VersForm,
            'VersProg' => $VersProg
        ];
    }
}